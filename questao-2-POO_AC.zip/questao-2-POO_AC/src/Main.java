import Modelo.AlunoAcademia;

public class Main {

    public static void main(String[] args) {

        AlunoAcademia aluno1 = new AlunoAcademia(
                "caio domingues",
                123,
                "PREMIUM",
                true
        );

        aluno1.exibirInformacoes();

        System.out.println();

        aluno1.registrarAula();
        aluno1.registrarAula();

        System.out.println();

        aluno1.suspenderMensalidade();

        aluno1.registrarAula();

        System.out.println();

        aluno1.renovarMensalidade();

        aluno1.registrarAula();

        System.out.println();

        aluno1.exibirInformacoes();
    }
}