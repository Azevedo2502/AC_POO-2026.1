package Modelo;

public class AlunoAcademia {

    private String nome;
    private int matricula;
    private String planoMensal;
    private int totalAulasRealizadas;
    private boolean mensalidadeAtiva;

    public AlunoAcademia(String nome, int matricula, String planoMensal,
                         boolean mensalidadeAtiva) {

        this.nome = nome;
        this.matricula = matricula;
        this.totalAulasRealizadas = 0;
        this.mensalidadeAtiva = mensalidadeAtiva;
    }

    public void registrarAula() {

        if (mensalidadeAtiva) {
            totalAulasRealizadas++;
            System.out.println("Aula registrada.");
        } else {
            System.out.println("Acesso bloqueado por inadimplencia.");
        }
    }

    public void renovarMensalidade() {

        mensalidadeAtiva = true;
        totalAulasRealizadas = 0;

        System.out.println("Mensalidade renovada.");
    }

    public void suspenderMensalidade() {

        if (mensalidadeAtiva) {
            mensalidadeAtiva = false;
            System.out.println("Mensalidade suspensa.");
        } else {
            System.out.println("Mensalidade ja esta inativa.");
        }
    }

    public void exibirInformacoes() {

        System.out.println("Nome: " + nome);
        System.out.println("Matricula: " + matricula);
        System.out.println("Plano: " + planoMensal);
        System.out.println("Total de aulas: " + totalAulasRealizadas);
        System.out.println("Mensalidade ativa: " + mensalidadeAtiva);
    }
}