package Modelo;

public class Passagem {

    private String codigoReserva;
    private String nomePassageiro;
    private String origem;
    private String destino;
    private double valorTarifa;
    private double dividaExistente;
    private String statusReserva;

    public Passagem(String codigoReserva, String nomePassageiro,
                    String origem, String destino,
                    double valorTarifa, String statusReserva) {

        this.codigoReserva = codigoReserva;
        this.nomePassageiro = nomePassageiro;
        this.origem = origem;
        this.destino = destino;
        this.valorTarifa = valorTarifa;
        this.dividaExistente = 0;
        this.statusReserva = statusReserva;
    }

    public void confirmarReserva() {

        if (statusReserva.equals("CANCELADA")) {
            System.out.println("Nao e possivel confirmar reserva cancelada.");
        } else {
            statusReserva = "CONFIRMADA";
            System.out.println("Reserva confirmada.");
        }
    }

    public void cancelarReserva() {

        if (statusReserva.equals("CANCELADA")) {

            System.out.println("Reserva ja cancelada.");

        } else {

            if (statusReserva.equals("CONFIRMADA")) {

                double multa = valorTarifa * 0.15;
                dividaExistente += multa;

                System.out.println("Multa aplicada: " + multa);
            }

            statusReserva = "CANCELADA";

            System.out.println("Reserva cancelada.");
        }
    }

    public void aplicarUpgrade(double valorAdicional) {

        if (valorAdicional < 0) {

            System.out.println("Valor invalido.");

        } else if (statusReserva.equals("CONFIRMADA")
                || statusReserva.equals("AGUARDANDO")) {

            valorTarifa += valorAdicional;
            dividaExistente += valorAdicional;

            System.out.println("Upgrade aplicado.");

        } else {

            System.out.println("Nao e possivel aplicar upgrade.");
        }
    }

    public void exibirInformacoes() {

        System.out.println("Codigo da reserva: " + codigoReserva);
        System.out.println("Passageiro: " + nomePassageiro);
        System.out.println("Trecho: " + origem + " -> " + destino);
        System.out.println("Valor tarifa: " + valorTarifa);
        System.out.println("Divida existente: " + dividaExistente);
        System.out.println("Status: " + statusReserva);
    }
}