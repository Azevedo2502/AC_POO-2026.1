import Modelo.Passagem;

public class Main {

    public static void main(String[] args) {

        Passagem p1 = new Passagem(
                "ABC123",
                "Caio Domingues",
                "GIG",
                "GRU",
                1200.0,
                "AGUARDANDO"
        );

        p1.exibirInformacoes();

        System.out.println();

        p1.confirmarReserva();

        p1.aplicarUpgrade(300);

        System.out.println();

        p1.exibirInformacoes();

        System.out.println();

        p1.cancelarReserva();

        System.out.println();

        p1.exibirInformacoes();
    }
}