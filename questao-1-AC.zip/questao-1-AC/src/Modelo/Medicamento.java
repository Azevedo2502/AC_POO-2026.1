package Modelo;

public class Medicamento {

    private String nome;
    private String principioAtivo;
    private int quantidadeEstoque;
    private double precoUnitario;
    private boolean necessitaReceita;

    public Medicamento(String nome, String principioAtivo, int quantidadeEstoque,
                       double precoUnitario, boolean necessitaReceita) {

        this.nome = nome;
        this.principioAtivo = principioAtivo;
        this.quantidadeEstoque = quantidadeEstoque;
        this.precoUnitario = precoUnitario;
        this.necessitaReceita = necessitaReceita;
    }

    public void entradaEstoque(int quantidade) {

        if (quantidade > 0) {
            quantidadeEstoque += quantidade;
            System.out.println("Estoque atualizado.");
        } else {
            System.out.println("Quantidade invalida.");
        }
    }

    public void venderUnidades(int quantidade) {

        if (quantidade <= quantidadeEstoque && quantidade > 0) {
            quantidadeEstoque -= quantidade;
            System.out.println("Venda realizada.");
        } else {
            System.out.println("Estoque insuficiente.");
        }
    }

    public void aplicarReajuste(double percentual) {

        if (percentual >= 0 && percentual <= 100) {
            precoUnitario += precoUnitario * (percentual / 100);
            System.out.println("Preco reajustado.");
        } else {
            System.out.println("Percentual invalido.");
        }
    }

    public void exibirInformacoes() {

        System.out.println("Nome: " + nome);
        System.out.println("Principio ativo: " + principioAtivo);
        System.out.println("Quantidade em estoque: " + quantidadeEstoque);
        System.out.println("Preco unitario: " + precoUnitario);
        System.out.println("Necessita receita: " + necessitaReceita);
    }
}