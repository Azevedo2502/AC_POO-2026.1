import Modelo.Medicamento;

public class Main {

    public static void main(String[] args) {

        Medicamento m1 = new Medicamento(
                "Dipirona",
                "Metamizol",
                50,
                10.0,
                false
        );

        m1.exibirInformacoes();

        System.out.println();

        m1.entradaEstoque(20);

        m1.venderUnidades(10);

        m1.aplicarReajuste(15);

        System.out.println();

        m1.exibirInformacoes();
    }
}